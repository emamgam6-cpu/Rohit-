NetEarn / GBSELL-inspired demo

This is a browser-only prototype. It uses localStorage for demo balances, tasks and profile fields.

It does NOT:
- collect bank/card/real UPI credentials
- access or sell device/network data
- process real money
- connect to Telegram/YouTube payment systems
- provide a real financial service

To run: open index.html in a browser. For public hosting, upload the folder to a static hosting service that supports HTML/CSS/JS.
