const KEY="netearn_demo_state";
function state(){return JSON.parse(localStorage.getItem(KEY)||'{"balance":0,"completed":0,"tasks":[],"profile":{}})}
function save(s){localStorage.setItem(KEY,JSON.stringify(s))}
function money(n){return "₹"+Number(n||0).toFixed(2)}
function addDemo(n){let s=state();s.balance+=n;save(s);render();alert("Demo earnings added: "+money(n))}
function completeTask(id,reward){let s=state();if(s.tasks.includes(id))return; s.tasks.push(id);s.completed++;s.balance+=reward;save(s);render()}
const tasks=[["watch","Watch demo video",100],["channel","Open demo channel page",100],["daily","Complete daily demo activity",50]];
function render(){
 const s=state();
 const b=document.getElementById("balance");if(b)b.textContent=money(s.balance);
 const wb=document.getElementById("withdrawBalance");if(wb)wb.textContent=money(s.balance);
 const c=document.getElementById("completed");if(c)c.textContent=s.completed;
 const name=document.getElementById("name");if(name)name.value=s.profile.name||"";
 const email=document.getElementById("email");if(email)email.value=s.profile.email||"";
 const list=document.getElementById("taskList");
 if(list)list.innerHTML=tasks.map(t=>{let done=s.tasks.includes(t[0]);return `<div class="card task"><div><h3>${t[1]}</h3><p>Reward: ${money(t[2])} demo credit</p></div><button class="btn" ${done?"disabled":""} onclick="completeTask('${t[0]}',${t[2]})">${done?"Completed":"Complete"}</button></div>`}).join("");
}
function saveProfile(){let s=state();s.profile={name:document.getElementById("name").value.trim(),email:document.getElementById("email").value.trim()};save(s);document.getElementById("saved").textContent="Demo profile saved locally."}
function requestWithdraw(){let s=state(),a=Number(document.getElementById("amount").value),m=document.getElementById("method").value,msg=document.getElementById("withdrawMsg");if(!a||a<=0){msg.textContent="Enter a valid demo amount.";return}if(a>s.balance){msg.textContent="Insufficient demo balance.";return}s.balance-=a;save(s);msg.textContent=`Demo withdrawal request of ${money(a)} via ${m} created. No real payment was made.`;render()}
render();